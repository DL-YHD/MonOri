_base_ = ['../_base_/onnx_config.py']
codebase_config = dict(type='mmseg', task='Segmentation', with_argmax=True)
