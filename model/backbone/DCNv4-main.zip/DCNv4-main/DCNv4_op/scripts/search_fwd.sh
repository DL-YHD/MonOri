python search_dcnv4_engine.py > res.txt
python find_best.py --input res.txt --output table.py